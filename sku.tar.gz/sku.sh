#!/bin/bash

PASSWORD=srgb.xyz

# 客户端配置参考(前两个可以路由运行,但是最后一个最好不要,路由性能有限,会让你觉得网络卡炸的.)
# 在本地windows 运行udp2raw 和 kcp-client，假设server ip是144.202.95.95：
# ./udp2raw -c -r144.202.95.95:8855 -l0.0.0.0:4000 -k"passwd" --raw-mode faketcp
# ./kcp-client -r "127.0.0.1:4000" -l ":3322" -mode fast2 -mtu 1300
# SS 客户端 => 混淆:aes-256-gcm, IP:127.0.0.1:3322, 密码:刚才设置的密码.
# 加速的 SSH登陆  # ssh -p 3322 root@127.0.0.1

# 远程服务器参数参考 ss-server   udp2raw  kcp-server 参考
# ss-server -s 127.0.0.1 -p 40000 -k xxx -m aes-256-gcm -t 300
# udp2raw -s -l0.0.0.0:8855 -r 127.0.0.1:4000 -k "passwd" --raw-mode faketcp
# kcp-server -t "127.0.0.1:40000" -l ":4000" -mode fast2 -mtu 1300

# 加速SSH使用参数
# kcp-server -t "127.0.0.1:22"  -l ":4000"  -mode fast2 -mtu 1300


# 停止原先服务
systemctl stop rc-local

# 复制服务端软件
cp ss-server  /usr/local/bin/ss-server
cp kcp-server /usr/bin/kcp-server
cp udp2raw    /usr/bin/udp2raw

#安装到启动项

cat <<EOF >/etc/rc.local
#!/bin/sh -e
#
# rc.local
#
# This script is executed at the end of each multiuser runlevel.
# Make sure that the script will "exit 0" on success or any other
# value on error.
#
# In order to enable or disable this script just change the execution
# bits.
#
# By default this script does nothing.

ss-server -s 127.0.0.1 -p 40000 -k ${PASSWORD} -m aes-256-gcm -t 300 >> /var/log/ss-server.log &
kcp-server -t "127.0.0.1:40000" -l ":4000" -mode fast2 -mtu 1300  >> /var/log/kcp-server.log &
udp2raw -s -l0.0.0.0:8855 -r 127.0.0.1:4000 -k "passwd" --raw-mode faketcp  >> /var/log/udp2raw.log &

exit 0
EOF

chmod +x /etc/rc.local
systemctl restart rc-local


