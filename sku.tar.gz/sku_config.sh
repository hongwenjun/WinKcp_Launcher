#!/bin/bash

PASSWORD=你的密码

# 停止原先服务
systemctl stop rc-local

# 复制服务端软件
cp ss-server  /usr/local/bin/ss-server
cp kcp-server /usr/bin/kcp-server
cp udp2raw    /usr/bin/udp2raw

#安装到启动项 适合debian 9 x64

cat <<EOF >/etc/rc.local
#!/bin/sh -e
#
# rc.local

ss-server -s 127.0.0.1 -p 40000 -k ${PASSWORD} -m aes-256-gcm -t 300 >> /var/log/ss-server.log &
kcp-server -t "127.0.0.1:40000" -l ":4000" -mode fast2 -mtu 1300  >> /var/log/kcp-server.log &
udp2raw -s -l0.0.0.0:8855 -r 127.0.0.1:4000 -k "passwd" --raw-mode faketcp  >> /var/log/udp2raw.log &

exit 0
EOF

chmod +x /etc/rc.local
systemctl restart rc-local


